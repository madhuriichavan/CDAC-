import java.util.*;

class Bank{
	String name;
	static String bankname;
	static {
		bankname="CDAC bank";
	}
	
	public Bank(String name){
		this.name=name;
	}
	
	void displaybank(){
		System.out.println("Account Holder: " +name+"Bank Name : "+bankname);
	}	
}
public class Name{
	public static void main (String[]args){
		
		Bank b1 = new Bank("madhuri");
		
		b1.displaybank();
	}
}
