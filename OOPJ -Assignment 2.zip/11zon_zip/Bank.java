import java.util.*;

class Account{
	String name;
	double bal;
	static double rate;
	
	static{
		rate =4.0;
	}
	Account(String name, double bal){
		this.name=name;
		this.bal=bal;
	}
	public String getname(){
	return name;
	}
	public double getbal(){
		return bal;
	}
	public void setname(String name){
		this.name=name;
	}
	public void setbal(double bal){
		this.bal=bal;
	}
	
	public void display(){
		System.out.println("name ="+ name+"balance = " +bal+"Interest rate = " +rate+"%");
	}
}
public class Bank{
	public static void main(String[]args){
		Scanner sc= new Scanner(System.in);
				
		Account a1= new Account("Rohit," , 5000);
		Account a2= new Account("Priya," , 15000);
		
        System.out.println("Bank Interest Rate Initialized: " + Account.rate + "%");
		
		a1.display();
		a2.display();
		
		sc.close();
	}
}
