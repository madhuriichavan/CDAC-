import java.util.*;

class Book{
	boolean issuetype;
	static int issuecount =0;
	
	Book(boolean issuetype){
		if (issuetype ){
			issuecount++;
		}
	}
	public boolean isIssued(){
		return issuetype;
	}
	
	
	public static void showTotalbooks(){
		System.out.println("Total books issued:"+ issuecount);
	}
}

public class Tracker2{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Book1: Harry Potter, Author: J.K. Rowling, Issued:");
		boolean issue1=sc.nextBoolean();
		System.out.println("Five Point Someone, Author: Chetan Bhagat, Issued:");
		boolean issue2=sc.nextBoolean();
		System.out.println("Rich Dad Poor Dad, Author: Robert Kiyosaki, Issued:");
		boolean issue3=sc.nextBoolean();
		
		Book book1 = new Book(issue1);
		Book book2 = new Book(issue2);
		Book book3 = new Book(issue3);
		
		System.out.println("Book1 issued? "+ issue1);
		System.out.println("Book2 issued? "+ issue2);
		System.out.println("Book3 issued? "+ issue3);
		
		Book.showTotalbooks();
		
		sc.close();
		
	}
}

		