import java.util.*;
class Book{
	
	private String title;
	private String author;
	static int totalbooks=0;
	
	public Book(String title, String author) {
        this.title = title;
        this.author = author;
        totalbooks++; 
	}
	
	public String gettitle(){
		return title;
	}
	public String getauthor(){
		return author;
	}
	public void settitle(String title){
		this.title=title;
	}
	public void setauthor(String author){
		this.author=author;
	}
	public void Displaybooks(){
		System.out.println("name" +title+"author"+author);

	}
	public static void Displaytotalbooks(){
		System.out.println("Total Books: "+totalbooks);
	}	
}
public class Library {
	public static void main(String[]args){
		Book b1=new Book("bhfgydefc", "bcisuchd");
		Book b2=new Book("vgfb", "nugnn");
		
		b1.Displaybooks();
		b2.Displaybooks();
		
		Book.Displaytotalbooks();

	}
}