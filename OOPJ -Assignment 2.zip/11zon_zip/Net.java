import java.util.*;

class Employee{
	private int id;
	private String name;
	private double basic;
	
	private static int counter = 1001;
	
	public Employee(){
		this.id=counter++;
		this.name="unknown";
		this.basic=20000;
	}
	public Employee(String name, double basic){
		this.id=counter++;
		this.name=name;
		this.basic=basic;
	}
	public int getId(){
		return id;
	}
	public String getname(){
		return name;
	}
	public double getbasic(){
		return basic;
	}
	
	public double netsalary(){
		double hra = 0.10 * basic;
		double da = 0.10 * basic;
		double pf = 0.10 * basic;
		return basic+hra+da-pf;
	}
	public void display(){
		System.out.println("ID:" +id+" name "+name+" Basic Salary "+basic);
		System.out.println("Net salary "+ netsalary());
	}	
}
public class Net{
	public static void main(String [] args){
		Employee e1= new Employee();
		Employee e2 = new Employee("madhuri", 53339);
		
		e1.display();
		e2.display();
	}
}
