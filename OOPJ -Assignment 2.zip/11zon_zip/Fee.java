import java.util.*;

class Student{
	private String name;
	private String clas;
	static int initial= 0;
	
	static {
		initial=30000;
		System.out.println("School Tuition Fee Initialized: "+initial);
	}
	
	public String getname(){
		return name;
	}
	public String getclas(){
		return clas;
	}
	public void setname(String name){
		this.name=name;
	}
	public void setclas(String clas){
		this.clas=clas;
	}
	
	public void details(){
		System.out.println("Name "+name+ ", Class="+clas+", Tuition fee="+ initial);
	}
}
public class Fee{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		Student s1=new Student();
		System.out.println("Student1: Name=");
		s1.setname(sc.nextLine());
		System.out.println("Class=");
		s1.setclas(sc.nextLine());
		Student s2=new Student();
		System.out.println("Student2: Name=");
		s2.setname(sc.nextLine());
		System.out.println("Class=");
		s2.setclas(sc.nextLine());
		
		System.out.println("Student1:");
		s1.details();
		System.out.println("Student2:");
		s2.details();
		
		
		sc.close();
	}
}

	
	