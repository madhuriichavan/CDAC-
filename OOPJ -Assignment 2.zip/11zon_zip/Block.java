import java.util.*;
class Vehicle{
    String regNo;
    String owner;	
	static {
        System.out.println("Welcome to CDAC Vehicle Registration Portal");
    }
	
	Vehicle(String regNo, String owner){
		this.regNo=regNo;
		this.owner=owner;
	}
	
	void display(){
		System.out.println("Vehicle no " +regNo+ " owner "+owner);
	}	
}
public class Block{
	public static void main(String[]args){
		Vehicle v1= new Vehicle("MH12AB1234", "Madhuri");
		v1.display();
		Vehicle v2= new Vehicle("MH12AB1224", "Sarang");
		v2.display();
		Vehicle v3= new Vehicle("MH12AB1211", "Manju");
		v3.display();
	}
}
