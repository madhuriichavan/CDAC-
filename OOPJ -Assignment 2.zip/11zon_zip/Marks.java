import java.util.*;
class Student{
	String name;
	int mar;
	static int totalstudents =0;
	
	Student(String name, int mar){
		this.name = name;
		this.mar= mar;
		totalstudents++;
	}
	
	public boolean status() {
		return mar >= 35;
	}
	
		
	public static void showtotalstudents(){
		System.out.println("Total students:" + totalstudents);
	}
}
	
public class Marks{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		Student s1 = new Student("Rahul", 78);
		Student s2 = new Student("Pooja", 34);
		Student s3 = new Student("Amit", 65);
		
		System.out.println("Student " +s1.name+ "Passed? "+ s1.status());
		System.out.println("Student " +s2.name+ "Passed? "+ s2.status());
		System.out.println("Student " +s3.name+ "Passed? "+ s3.status());
		
		Student.showtotalstudents();
		sc.close();
	}
}

	


	




		
		
