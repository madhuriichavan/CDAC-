import java.util.*;

class Account {
	private String name;
	private int amount;
	
	public String getname(){
		return name; 
	}
	
	public int getamount(){
		return amount; 
	}
	public void setname(String name){
		this.name=name;
	}
	
	public void setamount(int amount){
		this.amount=amount;
	}
	void Display(){
		System.out.println("Account holder :" +name+ " Balance: "+amount);

	}
}

public class Bankk{
	public static void main (String []args){
		
		Account a1 = new Account();
		
		a1.setname("Madhuri");
		a1.setamount(120 );
		
		a1.Display();
	}
}
