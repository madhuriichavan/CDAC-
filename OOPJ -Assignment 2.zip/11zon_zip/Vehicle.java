import java.util.*;

class Vehi{
	private String regno;
	private String name;
	private String type;
	static int vehicount=1020;
	
	public Vehi(String name,String type){
		vehicount++;
		this.regno="MH-2025-"+vehicount;
		this.name=name;
		this.type=type;
	}
	public String getregno(){
		return regno;
	}
	public String getname(){
		return name;
	}
	public String gettype(){
		return type;
	}
	public void display(){
		System.out.println("Register number:  " +regno+" owener: "+name+" Type: "+type);
	}		
	
}
public class Vehicle{	
	public static void main(String[]args){
		Vehi v1=new Vehi("MAdhuri","Car");
		Vehi v2=new Vehi("Sarang","bike");
		
		v1.display();
		v2.display();
		
		
	}
}
