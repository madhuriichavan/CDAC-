import java.util.*;

class Passenger{
	String name, seatype;
	int age;
	static int totalseats =0;
	
	Passenger(String name, int age){
		this.name=name;
		this.age=age;
		this.seatype="General";
		totalseats++;
	}
	Passenger(String name, int age,String seatype){
		this.name=name;
		this.age=age;
		this.seatype=seatype;
		totalseats++;
	}
	
	public String seat(){
		if (seatype.equals("AC Sleeper")){
			return  "AC Sleeper";
		}else {
			return "General";
		}
	}
	public static void showtotalpassenger(){
		System.out.println("Total Passengers Booked: "+ totalseats);
	}
	
}

public class India{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		Passenger p1 = new Passenger("Ravi,", 25);
		Passenger p2 = new Passenger("Anita,", 30,"AC Sleeper");
		Passenger p3 = new Passenger("Suresh,", 40);
		
		System.out.println("Passenger1: Name: "+p1.name+"Age: "+p1.age+"Seat: "+p1.seat());
		System.out.println("Passenger2: Name: "+p2.name+"Age: "+p2.age+"Seat: "+p2.seat());
		System.out.println("Passenger3: Name: "+p3.name+"Age: "+p3.age+"Seat: "+p3.seat());
		
		Passenger.showtotalpassenger();
		sc.close();
	}
}

		