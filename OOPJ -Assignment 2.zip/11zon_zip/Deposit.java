import java.util.*;

class Account{
	String name;
	double bal;
	
	public Account(String name,double bal){
		this.name=name;
		this.bal=bal;
	}
	
	public void deposit(double amount){
		if(amount> 0){
			bal+=amount;
			System.out.println(name+"deposited: "+amount);
		}else {
			System.out.println("Invalid deposit");
		}
	}
	
	public void withdraw(double amount){
		if(amount >0 && amount<= bal){
			bal -=amount;
		}else{
			System.out.println("insufficient balance: ");
		}
	}
	
	public void display(){
		System.out.println("Account Holder: "+name+" Balance: "+bal);
	}
}
public class Deposit{
	public static void main(String[]args){
		
		Account a1 = new Account("madhuri",5000);
		Account a2 = new Account("sarang",3000);
		
		a1.deposit(2000);
		a1.deposit(1000);
		a1.withdraw(6000);
		a1.withdraw(4000);
		
		a1.display();
		a2.display();
	}
}
