import java.util.*;

class Mobile{
	
	String mobType;
	static int totalMob =0;
	
	Mobile(String mobType){
		this.mobType=mobType;
		totalMob++;
	}
	
	public String getMobType(){
		return mobType;
	}
	
	public static void showTotalMob(){
		System.out.println("Total Mobiles in stock:" + totalMob);
	}
}

public class Tracker{
	public static void main (String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Mobile1 :model=");
		String mobName1= sc.nextLine();
		
		System.out.println("Mobile2 :mode2=");
		String mobName2= sc.nextLine();
	
	Mobile mob1 = new Mobile (mobName1);
	Mobile mob2 = new Mobile (mobName2);
	
	System.out.println("Mobile1 model:" + mob1.getMobType());
	System.out.println("Mobile2 mode2:" + mob2.getMobType());
	
	Mobile.showTotalMob();
	}
}



	
		