class Student{
	private String name;
	private int no;
	private int marks;
	
	
	public String getname(){
		return name;
	}
	public int getno(){
		return no;
	}
	public int getmarks(){
		return marks;
	}
	public void setname(String name){
		this.name=name;
	}
	public void setno(int no){
		this.no=no;
	}
	public void setmarks(int marks){
		this.marks=marks;
	}
	
	void Display(){
		System.out.println("name= " +name+ " Roll no = " +no + " Marks= "+marks);
	}	
}
public class Check{
	public static void main (String[]args){		
		Student s1 = new Student();
		
		s1.setname("Madhuri");
		s1.setno(123);
		s1.setmarks(90);
		
		
		s1.Display();
		
	}
}

		