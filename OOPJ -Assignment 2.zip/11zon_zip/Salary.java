import java.util.*;

class Employee{
	String name;
	int sal;
	int ser;
	static int totalemployees =0;
	
	Employee(String name, int sal,int ser){
		this.name=name;
		this.sal=sal;
		this.ser=ser;
		totalemployees++;
	}
	
	public double Bonus(){
		if(ser>5){
			return sal*0.05;
		}else {
			return 0.0;
		}
	}
	
	public static void showTotalEmployee(){
		System.out.println("Total employees:" + totalemployees);
	}
}



public class Salary{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
	
	
		Employee e1 = new Employee("Ravi", 150000, 6);
		Employee e2 = new Employee("Anita", 120000, 3);
		Employee e3 = new Employee("Suresh", 100000, 5);
		
		System.out.println("Employee1 " +e1.name+ " Bonus:" +e1.Bonus());
		System.out.println("Employee2 " +e2.name+ " Bonus:" +e2.Bonus());
		System.out.println("Employee3 " +e3.name+ " Bonus:" +e3.Bonus());

		Employee.showTotalEmployee();
		sc.close();
	}
}



	
	
	
	