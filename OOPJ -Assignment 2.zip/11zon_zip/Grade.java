import java.util.*;

class Student{
	String name;
	int marks;
	
	Student(String name,int marks){
		this.name=name;
		this.marks=marks;
	}
	
	String calculate(){
		String cal = (marks>=80)?"A":(marks>=60)?"B": (marks>=40)?"C":"fail";
		return cal;
	}	
}

public class Grade{
	public static void main(String[]args){
				
		Student s1 = new Student("Madhuri", 90);
		Student s2 = new Student ("Sarang", 78);
		
		System.out.println("Name = " +s1.name+ "Marks= " +s1.marks+" Grade=" + s1.calculate());
		System.out.println("Name = " +s2.name+ "Marks= " +s2.marks+" Grade=" + s2.calculate());
		
	}
}
