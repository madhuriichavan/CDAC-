import java.util.*;
class Employee{
	private int id;
	private String name;
	private double salary;
	
	private static int counter = 1001;
	
	public Employee(){
		this.id=counter++;
		this.name="Unknown";
		this.salary=20000;
	}
	
	public Employee(String name, double salary) {
        this.id = counter++;
        this.name = name;
        this.salary = salary;
    }
	
	public int getID(){
		return id;
	}
	public String getName(){
		return name;
	}
	public double getSalary(){
		return salary;
	}
	public void display(){
		System.out.println("ID: " +id+", Name: " +name+", salary: " +salary);
	}
}
public class Id{
	public static void main(String[]args){
		Employee e1 =new Employee();
		Employee e2 = new Employee("Madhuri", 35000);
		
		e1.display();
		e2.display();
	}
}
