import java.util.*;
class Customer {
	String name;
	String ticketype;
	static int totalticket=0;
	
	Customer(String name){
		this.name=name;
		this.ticketype="Normal";
		totalticket++;
	}
	
	Customer(String name, String ticketype){
		this.name=name;
		this.ticketype=ticketype;
		totalticket++;
	}
	
	public String type(){
		if(ticketype.equals("Premium")){
			return "Premium";
		}else{
			return "Normal";
		}
	}
	
	public static void showtotalticket(){
		System.out.println("Total Tickets Sold: " +totalticket);
	}
	
}

public class Indian{
	public static void main (String[]args){
		Scanner sc = new Scanner(System.in);
		
		Customer c1= new Customer("Rahul, ");
		Customer c2= new Customer("Pooja,", "Premium");
		Customer c3= new Customer("Amit, ");
		
		System.out.println("Customer1: Name: "+c1.name+ " Ticket: "+c1.type());
		System.out.println("Customer1: Name: "+c2.name+ " Ticket: "+c2.type());
		System.out.println("Customer1: Name: "+c3.name+ " Ticket: "+c3.type());
		
		
		Customer.showtotalticket();
		sc.close();
	}
}
