import java.util.*;
class Book{
	String name;
	int id;
	static int no=500;
	
	
	public Book(String name){
		this.name=name;
		this.id=no++;
	}
	void display(){
		System.out.println("Ticket No: "+id+", Passenger:"+name);
	}
	
}
public class Booking{
	public static void main(String[]args){
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Passenger 1:");
		Book b1=new Book(sc.nextLine());
		System.out.println("Passenger 2:");
		Book b2=new Book(sc.nextLine());
		System.out.println("Passenger 3:");
		Book b3=new Book(sc.nextLine());
		b1.display();
		b2.display();
		b3.display();
		
		sc.close();
	}
}
