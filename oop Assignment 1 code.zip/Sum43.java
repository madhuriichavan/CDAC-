import java.util.*;
public class Sum43{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number");
		int a = sc.nextInt();
		
		int sum = 0;
		int temp = a;
		
		while (temp >0){
			int digit = temp % 10;
			sum +=digit;
			temp /= 10;
		}
		System.out.println("Sum of digits: " + sum);
		sc.close();
	}
}
