import java.util.*;
public class Month22{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Month number:");
		int mon = sc.nextInt();
		
		String result= (mon ==1)? "Month is January"
					: (mon ==2)? "Month is February"
					: (mon ==3)? "Month is March"
					: (mon ==4)? "Month is April"
					: (mon ==5)? "Month is May"
					: (mon ==6)? "Month is June"
					: (mon ==7)? "Month is July"
					: (mon ==8)? "Month is Augest"
					: (mon ==9)? "Month is Septamber"
					: (mon ==10)? "Month is Octomber"
					: (mon ==11)? "Month is November"
					: (mon ==12)? "Month is December"
					: "invalid month number";
					
		System.out.println(result);
		sc.close();
	}
}
