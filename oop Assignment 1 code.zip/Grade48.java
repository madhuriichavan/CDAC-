import java.util.*;
public class Grade48{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number:");
		int a = sc.nextInt();
		
		String score = (a >=85 && a<=100)? "A" :
					(a>=75 )? "A-":
					(a>=65 )? "B":
					(a>=55 )?"B-":
					(a<=54)?"F": "Invalid";
		
		System.out.println("Grade:" + score);
		
		sc.close();
	}
}
