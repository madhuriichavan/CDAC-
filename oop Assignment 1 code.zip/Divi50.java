import java.util.*;
public class Divi50{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number:");
		int a = sc.nextInt();
		
		
		String num = (a%2==0)? "Divisible by 2":"";
		String num1 =(a%3==0)? "Divisible by 3":"";
		String num2 =(a%5==0)? "Divisible by 5":"";
					
					
		System.out.println(num);
		System.out.println(num1);
		System.out.println(num2);
	
		sc.close();
	}
}

			