import java.util.Scanner;
public class Salary2{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		int company1 = 45000;
		int company2 = 52000;
		int company3 = 50000;
		
	if (company1 >company2 && company1> company3){
		System.out.println("Company 1 has the highest salary");
	}else if (company2 > company3 && company2 > company1){
		System.out.println("Company 2 has the highest salary");
	}else{
		System.out.println("Company 3 has the highest salary");
	}
	
	sc.close();
	}
}

