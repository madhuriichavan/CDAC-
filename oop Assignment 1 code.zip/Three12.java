import java.util.Scanner;
public class Three12{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter age of Friend 1:");
		int frd1 = sc.nextInt();
		System.out.println("Enter age of Friend 2:");
		int frd2 = sc.nextInt();
		System.out.println("Enter age of Friend 3:");	
		int frd3 = sc.nextInt();
		
		if (frd1>frd2 && frd1>frd3){
			System.out.println("Oldest: Friend 1");
		}else if (frd2>frd1 && frd2>frd3){
			System.out.println("Oldest: Friend 2");
		}else{
			System.out.println("Oldest: Friend 3");
		}
		
		if (frd1<frd2 && frd1<frd3){
			System.out.println("Youngest: Friend 1");
		}else if (frd2<frd1 && frd2<frd3){
			System.out.println("Youngest: Friend 2");
		}else{
			System.out.println("Youngest: Friend 3");
		}
		
		sc.close();
	}
}

		
			
		
		

		