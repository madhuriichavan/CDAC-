import java.util.*;
public class Great31{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter first number:");
		int a = sc.nextInt();
		
		System.out.println("Enter second number:");
		int b = sc.nextInt();
		
		int greatest=(a>b)? a : b ;
		
				
		System.out.println("Greatest number:"+ greatest);
		
				sc.close();
	}
}
