import java.util.*;
public class Dis40{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Purchase amount:");
		double a = sc.nextDouble();
		
		double num = (a>1000)? a - (a*.10): a;
		
		System.out.println("Total cost after discount:" +num);
		
		sc.close();
	}
}
