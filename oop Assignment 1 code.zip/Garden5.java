import java.util.Scanner;
public class Garden5{
	public static void main (String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter Length:");
		int l=sc.nextInt();
		
		System.out.println("Enter Breadth:");
		int b = sc.nextInt();
		
		if (l == b){
			System.out.println("Square Garden");
		}else {
			System.out.println("Rectangular Garden");
		}
		
		sc.close();
	}
}
