import java.util.*;
public class Grade24{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter First number:");
		int marks = sc.nextInt();
		
		if (marks < 0 || marks > 100) {
            System.out.println("Invalid marks! Please enter between 0 and 100.");
        } else {
            char grade;

            switch (marks / 10) {
                case 10: // for 100
                case 9:
                case 8:  // 85–100
                    grade = 'A';
                    break;
                case 7:  // 70–84
                    grade = 'B';
                    break;
                case 6:  // 60–69
                case 5:  // 55–59
                    if (marks >= 55) {
                        grade = 'C'; // 55–69
                    } else {
                        grade = 'D'; // 45–54
                    }
                    break;
                case 4:  // 40–49
                    if (marks >= 45) {
                        grade = 'D';
                    } else {
                        grade = 'E';
                    }
                    break;
                case 3:  // 30–39
                case 2:  // 20–29
                    if (marks >= 25) {
                        grade = 'E';
                    } else {
                        grade = 'F';
                    }
                    break;
                case 1: // 10–19
                case 0: // 0–9
                    grade = 'F';
                    break;
                default:
                    grade = 'F';
            }

            System.out.println("Grade: " + grade);
        }
		
		sc.close();
	}
}

			
			
		
