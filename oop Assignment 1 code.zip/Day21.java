import java.util.*;
public class Day21{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter day number:");
		int day = sc.nextInt();
		
		String result = (day ==1)? "Day is monday"
					: (day ==2)? "Day is tuesday"
					: (day ==3)? "Day is wenesday"
					: (day ==4)? "Day is thursday"
					: (day ==5)? "Day is friday"
					: (day ==6)? "Day is saturday"
					: (day ==7)? "Day is sunday"
					: " Invalid day number";
					
		System.out.println(result);
		
		sc.close();
	}
}

					