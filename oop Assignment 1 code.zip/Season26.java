import java.util.*;
public class Season26{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a number:");
		int a = sc.nextInt();
		
		/*if (a==12 || a==1 || a == 2){
			System.out.println("season is Winter");
		}else if  (a ==3 || a ==4 || a==5){
			System.out.println("season is Summer");
		}else if (a == 6 || a ==7 || a == 8){
			System.out.println("season is Monsoon");
		}else if (a == 9 || a == 10|| a == 11){
			System.out.println("season is Autumn");
		}else {
			System.out.println("Enter a valid number:");
		}*/
		String season;
		switch (a){
			case 12:
			case 1:
			case 2:
			season = "winter";
			break;
			case 3:
			case 4:
			case 5:
			season = "summer";
			break;
			case 6:
			case 7:
			case 8:
			season = "mansoon";
			break;
			case 9:
			case 10:
			case 11:
			season = "Autumn";
			break;
			default:
			season ="Enter a valid number";
			
		}	
			System.out.println("Season is" + season);
		
		sc.close();
	}
}
