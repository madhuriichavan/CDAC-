import java.util.*;
public class Bonus39{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Salary:");
		double a = sc.nextDouble();
		
		System.out.println("Enter Years of service:");
		int b = sc.nextInt();
		
		double num = (b<5)? a * .05 : 0;
		
		
		System.out.println("Bonus: " + num);
		
		sc.close();
	}
}
