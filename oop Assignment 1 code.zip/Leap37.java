import java.util.*;
public class Leap37{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Year:");
		int a = sc.nextInt();
		
		String num = ((a%4==0 && a%100!=0) || (a%400==0))? "Leap Year" : "not a leap year";
		System.out.println(num);
		
		sc.close();
	}
}
