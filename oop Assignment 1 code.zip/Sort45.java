import java.util.*;
public class Sort45{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		int[] arr = new int[3];
		
		System.out.println("Enter 1st Number");
		arr[0] = sc.nextInt();
		
		System.out.println("Enter 2nd Number");
		arr[1] = sc.nextInt();
		
		System.out.println("Enter 3rd Number");
		arr[2] = sc.nextInt();
		
		Arrays.sort(arr);
		
		System.out.println("Ascending order: " + arr[0] + ", " + arr[1] + ", " + arr[2]);

		

        sc.close();
    }
}
		
				