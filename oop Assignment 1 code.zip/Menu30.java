import java.util.*;
public class Menu30{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Select operation : 1-Addition, 2-Subtraction, 3-Multiplication, 4-Division");
		int op = sc.nextInt();
		
		System.out.println("Enter first number:");
		int a = sc.nextInt();
		
		System.out.println("Enter second number:");
		int b = sc.nextInt();
		
		int result=0;	
			
		switch (op){
			case 1:
				result = (a + b);
				System.out.println("Result: " + result);
				break;
			case 2:
				result = (a - b);
				System.out.println("Result: " + result);
				break;
			case 3:
				result = (a * b);
				System.out.println("Result: " + result);
				break;
			case 4:
				result = (a / b);
				System.out.println("Result: " + result);
				break;
			
		}
		sc.close();
	}
}

			
		
		
		