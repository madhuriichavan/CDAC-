import java.util.*;
public class Vote34{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter age:");
		int a = sc.nextInt();
		
		String num = (a>=20)? "Eligible" : "Not Eligible";
		
		System.out.println(num + "to vote");
		
		sc.close();
	}
}

		
		