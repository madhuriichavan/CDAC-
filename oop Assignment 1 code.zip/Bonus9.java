import java.util.Scanner;
public class Bonus9{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter Salary:");
		double salary = sc.nextDouble();
		
		System.out.println("Enter Experience:");
		double exp = sc.nextDouble();
		
		
		
		if (exp >= 5 ){
			salary = salary * 0.05;
			System.out.println("Bonus amount:" + salary);
		}else {
			System.out.println("Experience is less.");
		}
		
		
		
		
		sc.close();
	}
}

		