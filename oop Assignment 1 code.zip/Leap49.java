import java.util.*;
public class Leap49{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Year:");
		int a = sc.nextInt();
		
		System.out.println("Enter Month Number:");
		int b = sc.nextInt();
		
		if (b==1 || b == 3 || b == 5|| b == 8 || b== 7|| b==10 || b ==12){
			System.out.println("31 days");
		}else if ( b== 4|| b== 6  || b== 9|| b==11){
			System.out.println("30 days");
		}else if (b==2) {
			if ((a %4 ==0 && a %100!=0) || (a%400==0)){
				System.out.println("29 days");
			}else {
			System.out.println("28 days");
			}
		}else {
			System.out.println("Invalid month number");
		}

		
		sc.close();
	}
}

