import java.util.Scanner;

public class Score1{
	public static void main(String[]args){
		Scanner sc = new Scanner (System.in);
		
		int test1 =sc.nextInt();
		int test2 =sc.nextInt();
		
		if (test1 >test2){
			System.out.println("Test 1 has higher score");
		}else if (test2> test1){
			System.out.println("Test 2 has higher score");
		}else{
			System.out.println("both tests have equal score");
		}
		
		sc.close();
		
	}
}

		