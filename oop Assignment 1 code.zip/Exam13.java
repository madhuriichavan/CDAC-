import java.util.Scanner;
public class Exam13{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("classes held:");
		int held = sc.nextInt();
		System.out.println("Classes attended:");
		int attend = sc.nextInt();
		System.out.println("Medical cause (Y/N):");
		char cause = sc.next().charAt(0);
		
		double per = (attend * 100.0) / held;
		
		if (per >= 75 || cause == 'Y' || cause == 'y'){
			System.out.println("Student is allowed to sit for the exam.");
		} else {
			System.out.println("Student is allowed to sit for the exam.");
		}
		
		sc.close();
	}
}


			
			
			
		
		
		