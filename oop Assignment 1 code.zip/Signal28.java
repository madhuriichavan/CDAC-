import java.util.*;
public class Signal28{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter traffic light color: ");
		String a = sc.next();
		
		switch (a){
			case "Red":
				System.out.println("Stop");
				break;
			case "Green":
				System.out.println("Go");
				break;
			case "Yellow":
				System.out.println("Slower the speed");
				break;
			default:
				System.out.println("Enter a valid traffic light color: ");
		}
		sc.close();
	}
}

				
				
			