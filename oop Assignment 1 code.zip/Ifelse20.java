import java.util.Scanner;
public class Ifelse20{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter first number:");
		int num1 = sc.nextInt();
		System.out.println("Enter second number:");
		int num2 = sc.nextInt();
		System.out.println("Enter operator:");
		char op= sc.next().charAt(0);
		
		int result = 0;
		
		
		if (op == '+'){
			result=num1+num2;
		}else if (op == '-'){
			result =num1-num2;
		}else if (op =='*'){
			result=num1*num2;
		}else if (op=='/'){
			result=num1/num2;
		}else{
			System.out.println("Resulr:" + result);
		}
		
		//return;
		
		
		sc.close();
		
		
	}
}

			
			