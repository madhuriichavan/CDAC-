import java.util.Scanner;
public class Luck15{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter 4-digit number:");
		int num = sc.nextInt();
		
		if (num <1000 || num >9999){
			System.out.println("Enter a valid number:");
		}else {
			int A = num / 1000;
			int B = (num /100)%10;
			int C = (num / 10)%10;
			int D = num % 10;
			
		
			if (( A+B) == (C+D)){
				System.out.println("Lucky number");
			}else{
				System.out.println("Not Lucky number");
			}
		}
		
		sc.close();
	}
}
		
			
			
			