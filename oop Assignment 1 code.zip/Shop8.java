import java.util.Scanner;
public class Shop8{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter total purchase amount:");
		double num = sc.nextDouble();
		
		double finalcost;
		
		if (num > 1000){
			finalcost = num - (num * 0.10);
		}else{
			finalcost = num;
		}
		
		System.out.println("Final cost after discount:" + finalcost);
		
		sc.close();
	}
}

		