import java.util.*;
public class Even47{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter 1st Number:");
		int a = sc.nextInt();
		
		System.out.println("Enter 2nd Number:");
		int b = sc.nextInt();
		
		if (a%2==0 && b%2==0){
			System.out.println("Both are even");
		}else if (a%2!=0 && b%2!=0){
			System.out.println("Both are odd");
		}else if (a%2==0 && b%2!=0){
			System.out.println("Numbers are mixed");
		}else{
			System.out.println("Numbers are mixed");
		}
		
		sc.close();
	}
}

		
		