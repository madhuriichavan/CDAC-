import java.util.*;
public class Digi44{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number");
		int a = sc.nextInt();
		
		int original = a;
		int reverse =0;
		
		while (a>0){
			int digit = a %10;
			reverse = reverse*10+digit;
			a /=10;
		}
		
		System.out.println("Reversed number:" +reverse);
		
		if (original == reverse){
			System.out.println("Palindrome: Yes");
		}else{
			System.out.println("Palindrome: No");
		}
		
		sc.close();
	}
}

			