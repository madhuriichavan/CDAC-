import java.util.*;
public class Small36{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Numbers:");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int num = (a<b && a<c)? a : (b<a && b<c)? b : c;
		
		System.out.println("Smallest Number:" + num);
		
		
		sc.close();
	}
}
