import java.util.*;
public class Arm41{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number");
		int a = sc.nextInt();
		
		int original = a;
		int sum =0;
		
		while(a >0){
			int digit = a %10;
			sum += digit * digit * digit;
			a /= 10;
		}
				
		if (sum == original){
			System.out.println(original + " is an Armstrong number");
		}else {
			System.out.println(original + "is not");
		}
		sc.close();
	}
}
