import java.util.Scanner;
public class Exam10{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter total classes held:");
		int total = sc.nextInt();
		
		System.out.println("Enter classes attended:");
		int attend = sc.nextInt();
		
		double percentage = (attend * 100.0)/ total;
		
		
		if ( percentage >= 75){
			System.out.println("Student is allowed to sit for the exam.");
		}else {
			System.out.println("Student is not allowed to sit for the exam.");
		}
		
		sc.close();
	}
}
