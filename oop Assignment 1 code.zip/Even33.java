import java.util.*;
public class Even33{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number:");
		int a = sc.nextInt();
				
		String num= (a %2 ==0)? "Even" : "Odd";
		
		System.out.println("Number is "+ num);
		
		sc.close();
	}
}
