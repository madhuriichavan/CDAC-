import java.util.*;
public class Type46{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter character:");
		char ch = sc.next().charAt(0);
		
		if (Character.isLetter(ch)){
			System.out.println("It is an Alphabet.");
		}else if (Character.isDigit(ch)){
			System.out.println("It is a Digit");
		}else{
			System.out.println("It is a special character");
		}
		
		sc.close();
	}
}
