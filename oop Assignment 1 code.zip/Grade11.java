import java.util.Scanner;
public class Grade11{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter percentage marks:");
		int per = sc.nextInt();
		
		if (per >= 90) {
			System.out.println("Grade: A+");
		}else if (per >= 76 && per <= 89){
			System.out.println("Grade: A");
		}else if (per >= 66 && per <= 75){
			System.out.println("Grade: B+");
		}else if (per >= 51 && per <= 65){
			System.out.println("Grade: B");
		}else if (per >= 36 && per <= 50){
			System.out.println("Grade: C");
		}else{
			System.out.println("Fail: ");
		}
		
		sc.close();
	}
}
