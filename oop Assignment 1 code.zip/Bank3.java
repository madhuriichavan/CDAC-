import java.util.Scanner;
public class Bank3{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter transaction amount: ");
		int i = sc.nextInt();
		if (i > 0 ){
			System.out.println("Deposite Transation ");
		}else if (i < 0 ){
			System.out.println("Withdrawal Transaction ");
		}else{
			System.out.println("No transaction");
		}
		sc.close();
	}
}

		