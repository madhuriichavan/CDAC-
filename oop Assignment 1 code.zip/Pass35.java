import java.util.*;
public class Pass35{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter marks:");
		int a = sc.nextInt();
		
		String num = (a >=35)? "Pass" : "fail";
		System.out.println(num);
		
		sc.close();
	}
}

		