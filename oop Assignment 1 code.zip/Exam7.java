import java.util.Scanner;
public class Exam7{
	public static void main(String[]args){
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter marks:");
		int num = sc.nextInt();
		
		if (num >= 35){
			System.out.println("Student has passed");
		}else {
			System.out.println("Student has failed");
		}
		sc.close();
	}
}
